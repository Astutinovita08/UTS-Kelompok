from django.apps import AppConfig


class TamuConfig(AppConfig):
    name = 'tamu'
